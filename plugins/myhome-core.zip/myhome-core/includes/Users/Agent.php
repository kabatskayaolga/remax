<?php

namespace MyHomeCore\Users;


/**
 * Class Agent
 * @package MyHomeCore\Users
 */
class Agent extends User {


}